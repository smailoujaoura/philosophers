/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   writing.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: soujaour <soujaour@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/08 21:08:21 by soujaour          #+#    #+#             */
/*   Updated: 2025/03/09 11:11:00 by soujaour         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// #include "philo.h"

// void	safe_writing_messages(t_philo *philo, char *message)
// {
// 	pthread_mutex_lock(&philo->sync->lock);
// 	printf("%zu ms %d %s\n", get_time(), philo->philo_number, message);
// 	pthread_mutex_unlock(&philo->sync->lock);
// }
