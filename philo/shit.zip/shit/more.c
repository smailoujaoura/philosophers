/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   more.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: soujaour <soujaour@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/19 11:56:55 by soujaour          #+#    #+#             */
/*   Updated: 2025/03/09 11:50:28 by soujaour         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

size_t	get_time(void)
{
	struct timeval	tv;

	gettimeofday(&tv, NULL);
	return (tv.tv_sec * 1000 + tv.tv_usec / 1000);
}

void    ft_msleep(size_t millisec)
{
    size_t    start_time;

    start_time = get_time();
	// usleep((millisec - 10) * 1000);
    while (millisec + start_time > get_time())
        usleep(50);
}

t_sync	*check_args(char *argv[], int optional)
{
	t_sync	*sync;
	int		error;

	error = 0;
	sync = malloc(sizeof(t_sync));
	memset(sync, 0, sizeof(t_sync));
	sync->total_philos = custom_atoi(argv[1], &error);
	sync->death_time = custom_atoi(argv[2], &error);
	sync->eat_time = custom_atoi(argv[3], &error);
	sync->sleep_time = custom_atoi(argv[4], &error);
	sync->total_cycles = -1;
	if (optional)
		sync->total_cycles = custom_atoi(argv[5], &error);
	if (error || !sync->death_time || !sync->eat_time || !sync->sleep_time)
		return (NULL);
	return (sync);
}


void	finalize_init(t_philo *philos, int total_philos)
{
	int	i;

	i = -1;
	while (++i < total_philos)
	{
		if (i == 0)
			philos[i].left_fork = &philos[total_philos - 1].right_fork;
		else
			philos[i].left_fork = &philos[i - 1].right_fork;
	}
	i = -1;
	while (++i < total_philos)
	{
		if (i % 2 == 0)
		{
			philos[i].first = philos[i].left_fork;
			philos[i].second = &philos[i].right_fork;
		}
		else
		{
			philos[i].first = &philos[i].right_fork;
			philos[i].second = philos[i].left_fork;
		}
	}
}

t_philo	*init_sync(t_sync *sync)
{
	int	i;
	t_philo	*philos;

	i = 0;
	philos = malloc(sizeof(t_philo) * sync->total_philos);
	if (philos == NULL)
		return (NULL);
	memset(philos, 0x0, sizeof(t_philo) * sync->total_philos);
	if (pthread_mutex_init(&sync->lock, NULL) != 0)
		return (NULL);
	while (i < sync->total_philos)
	{
		philos[i].philo_number = i + 1;
		philos[i].sync = sync;
		if (pthread_mutex_init(&philos[i].right_fork, NULL))
			return (NULL);
		i++;
	}
	finalize_init(philos, sync->total_philos);
	return (philos);
}

size_t	timer_stamper(int flag)
{
	static size_t	start;
	struct timeval	current;

	gettimeofday(&current, NULL);
	if (flag)
		start = current.tv_sec * 1000 + current.tv_usec / 1000;
	return ((current.tv_sec * 1000 + current.tv_usec / 1000) - start);
}