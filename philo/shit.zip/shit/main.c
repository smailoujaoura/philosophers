/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: soujaour <soujaour@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/08 14:37:01 by soujaour          #+#    #+#             */
/*   Updated: 2025/03/09 12:08:15 by soujaour         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

void	write_message_safely(t_philo *philo, char *message, char *message_two)
{
	if (message_two)
	{
		pthread_mutex_lock(&philo->sync->lock);
		printf("%zu ms %d %s\n", get_time() - philo->sync->start_time, philo->philo_number, message);
		printf("%zu ms %d %s\n", get_time() - philo->sync->start_time, philo->philo_number, message_two);
		pthread_mutex_unlock(&philo->sync->lock);
	}
	else
	{
		pthread_mutex_lock(&philo->sync->lock);
		printf("%zu ms %d %s\n", get_time() - philo->sync->start_time, philo->philo_number, message);
		pthread_mutex_unlock(&philo->sync->lock);
	}
}

void	*monit(void *ptr)
{
	t_philo	*philo;

	philo = ptr;
	while (!philo->sync->stop)
	{
		if (philo->last_meal_time + philo->sync->start_time < get_time())
		{
			write_message_safely(philo, "has died", NULL);
			philo->should_die = 1;
			philo->sync->stop = 1;
		}
		// usleep(1000);
	}
	return (NULL);
}

void	*routine(void *ptr)
{
	t_philo	*philo;

	philo = ptr;
	while (!philo->should_die && !philo->sync->stop)
	{
		pthread_mutex_lock(philo->first);
		write_message_safely(philo, "has taken a fork", NULL);
		pthread_mutex_lock(philo->second);
		philo->last_meal_time = get_time();
		write_message_safely(philo, "has taken a fork", "is eating");
		ft_msleep(philo->sync->eat_time);
		pthread_mutex_unlock(philo->second);
		pthread_mutex_unlock(philo->first);
		philo->meals_counter++;
		if (philo->meals_counter == philo->sync->total_cycles)
			philo->sync->all_ate++;
		write_message_safely(philo, "has taken a fork", NULL);
		ft_msleep(philo->sync->sleep_time);
		write_message_safely(philo, "is thinking", NULL);
	}
	return (NULL);
}

int	start_sync(t_philo *philos, t_sync *sync)
{
	int			i;
	pthread_t	monitor;

	i = -1;
	sync->start_time = get_time();
	while (++i < sync->total_philos)
	{
		philos[i].philo_number = i + 1;
		philos[i].last_meal_time = sync->start_time;
		philos[i].should_die = 0;
		philos[i].meals_counter = 0;
		philos[i].sync = sync;
		pthread_create(&philos[i].thread_id, NULL, routine, &philos[i]);
		pthread_create(&monitor, NULL, monit, &philos[i]);
		pthread_detach(monitor);
		i++;
		// usleep(100);
	}
	return (0);
}

int	main(int argc, char *argv[])
{
	t_sync	*sync;
	t_philo	*philos;
	
	if (argc == 5 || argc == 6)
	{
		sync = check_args(argv, argc == 6);
		if (sync == NULL || (argc == 6 && sync->total_cycles == 0))
			philos = NULL;
		else
		{
			philos = init_sync(sync);
			start_sync(philos, sync);
			int i = -1;
			while (++i < sync->total_philos)
				pthread_join(philos[i].thread_id, NULL);
		}
	}
	return (0);
}
