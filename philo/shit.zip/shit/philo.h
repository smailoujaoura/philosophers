/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: soujaour <soujaour@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/08 14:38:02 by soujaour          #+#    #+#             */
/*   Updated: 2025/03/09 11:23:41 by soujaour         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PHILO_H
# define PHILO_H

// Might need to remove some unsued headers at the end of the project.
# include <string.h>
# include <stdio.h>
# include <stdlib.h>
# include <unistd.h>
# include <sys/time.h>
# include <pthread.h>
# include <stdint.h>
# include <limits.h>

typedef struct s_sync
{
	int				total_philos;
	int				total_cycles;
	int				death_time;
	int				eat_time;
	int				sleep_time;
	int				stop;
	int				all_ate;
	size_t			start_time;
	pthread_mutex_t	lock;
}	t_sync;

typedef struct s_philo
{
	t_sync			*sync;
	pthread_t		thread_id;
	int				philo_number;
	int				meals_counter;
	int				should_die;
	size_t			last_meal_time;
	pthread_mutex_t	right_fork;
	pthread_mutex_t	*left_fork;
	pthread_mutex_t	*first;
	pthread_mutex_t	*second;
}	t_philo;


void	*ft_malloc(size_t size, int flag, void *one, void *two);
size_t	custom_atoi(const char *str, int *error);


// 
t_philo	*init_sync(t_sync *sync);
void	finalize_init(t_philo *philos, int total_philos);
void	*destroy_mutexes(t_philo *philos, size_t i, int flag);
void	precise_sleep(size_t micro_secs);
size_t	timer_stamper(int flag);
void    ft_msleep(size_t millisec);
t_sync	*check_args(char *argv[], int flag);
size_t	get_time(void);
int		safe_writing_messages(t_philo *philo, char *message, int f);


#endif